//
// Created by hoang on 9/11/2020.
//

#ifndef TWAIN_RABBITMQ_CLIENT_TWAIN_CONFIG_H
#define TWAIN_RABBITMQ_CLIENT_TWAIN_CONFIG_H

const char *BASE_URL = "http://3.236.65.227:5001/api/v1/";
const char *AUTHENTICATE = "/authenticate";
const char *SEARCH_DEVICE = "users/search/devices";

#endif //TWAIN_RABBITMQ_CLIENT_TWAIN_CONFIG_H
