#include <string>

std::string foo(const std::string &a, const std::string &b) {
  std::string sum;
   sum = a + b;
  return sum;
}
